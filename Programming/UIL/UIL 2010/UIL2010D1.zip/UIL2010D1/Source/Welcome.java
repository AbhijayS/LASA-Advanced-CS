import java.util.*;
import java.io.*;
import static java.lang.System.*;


public class Welcome {

	public static void main(String args[]) throws IOException
	{
		for(int i=0; i<10; i++)
			out.println("WELCOME TO THE UIL DISTRICT CONTEST");
	}
}
