
public class Longhorn {
    public static void main(String[] args){
        for(int i = 1; i <= 14; i++){
            System.out.println("|**********************|");
            System.out.println("|#######........#######|");
            System.out.println("|....####......####....|");
            System.out.println("|.......########.......|");
            System.out.println("|......##########......|");
            System.out.println("|........######........|");
            System.out.println("|..........##..........|");
            System.out.println("|..........##..........|");
            System.out.println("|..........##..........|");
            System.out.println("************************");
            System.out.println(i);
        }
    }
}
