import java.util.*;
import java.io.*;
import static java.lang.System.*;


public class Love {

	public static void main(String args[]) throws IOException
	{
		for(int i=0; i<12; i++)
			out.println("CINDY LOVES THE UIL PROGRAMMING CONTEST");
	}
}
